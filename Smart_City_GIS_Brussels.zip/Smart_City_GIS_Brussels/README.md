# Smart City GIS Web Page — Brussels

## Project title
**Urban Heat Risk Web Page for a Smart City: Brussels**

## Theme
Urban heat monitoring and risk mapping using **remote sensing + GIS**.

## Problem
Urban areas can become hotter because hard surfaces such as asphalt and concrete absorb and release heat. Limited vegetation and poor air circulation can intensify the urban heat-island effect.

## Solution
Create a web-based GIS decision-support page that identifies potential heat-risk hotspots, combines satellite and GIS information, displays a decision map, suggests cooling actions and collects user observations.

## Target user
Municipality / urban planner / city decision-maker.

## Data needed
- Landsat 8/9 Collection 2 Level-2 Surface Temperature for LST.
- Sentinel-2 imagery for vegetation indices such as NDVI.
- Brussels GIS/open data for land use, parks, buildings and roads.
- OpenStreetMap for web-map context.

## GIS / remote-sensing method
1. Acquire cloud-screened satellite images.
2. Clip data to Brussels.
3. Obtain LST from Landsat.
4. Calculate NDVI from Sentinel-2.
5. Calculate a built-up indicator such as NDBI where appropriate.
6. Standardise indicators and combine them into a heat-risk index.
7. Overlay cooling resources and urban features.
8. Publish the decision map on the web page.

## Final decision map / dashboard
Four prototype categories are shown: very high, high, moderate and lower/cooling. A real scientific version must replace the demo values with processed satellite/GIS results.

## Files
- `index.html` — complete webpage
- `styles.css` — design
- `script.js` — interactive map + form
- `images/brussels_heat_map.svg` — illustrative map
- `data/heat_risk_demo.csv` — illustrative data
- `README.md` — explanation
- `README.pdf` — short PDF explanation

## Assignment requirements covered
HTML5 structure; metadata; headings; paragraphs; emphasis; comments; sections; image/map with meaningful alt; internal anchor links; external data-source links; ordered and unordered lists; dataset table; and complete form with text, email, date, number, checkbox, select/options, textarea, fieldset/legend, submit and reset buttons.

## Important limitation
The map markers, scores and SVG heat zones are **illustrative demo data** for the assignment. They are not an official Brussels heat-risk assessment.

## Useful official sources
- City of Brussels: https://www.brussels.be/urban-cool-islands
- USGS Landsat Surface Temperature: https://www.usgs.gov/landsat-missions/landsat-collection-2-surface-temperature
- ESA Sentinel-2: https://www.esa.int/Applications/Observing_the_Earth/Copernicus/Sentinel-2
- OpenStreetMap: https://www.openstreetmap.org/
